#!/usr/bin/env bash
set -e
echo "Installing johnwalls.studio VST3 & AU plugins..."

mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components"

cp -R "johnwalls.studio.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/"
cp -R "johnwalls.studio.component" "$HOME/Library/Audio/Plug-Ins/Components/"

xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/VST3/johnwalls.studio.vst3" 2>/dev/null || true
xattr -dr com.apple.quarantine "$HOME/Library/Audio/Plug-Ins/Components/johnwalls.studio.component" 2>/dev/null || true

echo "✓ Successfully installed johnwalls.studio to:"
echo "  - $HOME/Library/Audio/Plug-Ins/VST3/johnwalls.studio.vst3"
echo "  - $HOME/Library/Audio/Plug-Ins/Components/johnwalls.studio.component"
echo "Restart your DAW to begin playing!"
